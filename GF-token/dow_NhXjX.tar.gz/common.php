<?php
/**
 * 公共JSON文件操作函数
 * 处理下载资源的增删改查
 */

// JSON文件路径
define('DOWNLOAD_JSON', __DIR__ . '/downloads.json');

/**
 * 初始化JSON文件
 */
function initJsonFile() {
    if (!file_exists(DOWNLOAD_JSON)) {
        $initialData = [];
        file_put_contents(DOWNLOAD_JSON, json_encode($initialData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        chmod(DOWNLOAD_JSON, 0755); // 设置文件权限
    }
}

/**
 * 获取所有下载资源
 */
function getDownloads() {
    initJsonFile();
    $jsonContent = file_get_contents(DOWNLOAD_JSON);
    return json_decode($jsonContent, true) ?: [];
}

/**
 * 添加新下载资源
 */
function addDownload($data) {
    $downloads = getDownloads();
    // 添加唯一ID和时间戳
    $newItem = [
        'id' => uniqid(),
        'name' => $data['name'],
        'url' => $data['url'],
        'created_at' => date('Y-m-d H:i:s')
    ];
    $downloads[] = $newItem;
    
    // 保存到JSON文件
    file_put_contents(
        DOWNLOAD_JSON,
        json_encode($downloads, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
    );
    return $newItem;
}