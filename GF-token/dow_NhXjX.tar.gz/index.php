<?php
/**
 * 下载资源展示页面
 * 仅显示名称和下载按钮，从JSON文件加载数据
 */
require 'common.php';

// 获取所有下载资源
$downloads = getDownloads();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>资源下载列表</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            padding: 2rem 1rem;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .page-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .page-title {
            color: #2c3e50;
            font-weight: 600;
            font-size: 2rem;
        }
        
        .download-list {
            display: grid;
            gap: 1rem;
        }
        
        .download-item {
            background: #fff;
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
        }
        
        .download-item:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            transform: translateY(-2px);
        }
        
        .resource-name {
            font-size: 1.1rem;
            color: #34495e;
            font-weight: 500;
        }
        
        .download-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 0.6rem 1.2rem;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        
        .download-btn:hover {
            background-color: #2980b9;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #7f8c8d;
        }
        
        .empty-state p {
            margin-top: 1rem;
            font-size: 1.1rem;
        }
        
        .add-link {
            display: inline-block;
            margin-top: 1.5rem;
            color: #3498db;
            text-decoration: none;
            font-weight: 500;
        }
        
        .add-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">资源下载中心</h1>
        </div>
        
        <div class="download-list">
            <?php if (!empty($downloads)): ?>
                <?php foreach ($downloads as $item): ?>
                    <div class="download-item">
                        <div class="resource-name"><?php echo htmlspecialchars($item['name']); ?></div>
                        <a href="<?php echo htmlspecialchars($item['url']); ?>" 
                           class="download-btn" 
                           download>
                            下载
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <h3>暂无下载资源</h3>
                </div>
            <?php endif; ?>
        </div>
        
        <div style="text-align: center; margin-top: 2rem;">
        </div>
    </div>
</body>
</html>